#include "stack.h"

void initialize(Stack *s) {
    s->top = -1;
}

int isEmpty(Stack *s) {
    return s->top == -1;
}

int isFull(Stack *s) {
    return s->top == MAX_SIZE - 1;
}

void push(Stack *s, int value) {
    if (!isFull(s)) {
        s->top++;
        s->data[s->top] = value;
    }
}

int pop(Stack *s) {
    if (!isEmpty(s)) {
        int value = s->data[s->top];
        s->top--;
        return value;
    }
    return -1; // Stack is empty
}

int peek(Stack *s) {
    if (!isEmpty(s)) {
        return s->data[s->top];
    }
    return -1; // Stack is empty
}
