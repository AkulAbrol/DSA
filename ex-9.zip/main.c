#include <stdio.h>
#include "stack.h"

void towerOfHanoi(int n, Stack *source, Stack *auxiliary, Stack *destination) {
    if (n <= 0) {
        return;
    }

    // Calculate the total number of moves
    int totalMoves = (1 << n) - 1;

    // Determine the direction of disk movement based on the number of disks
    char sourceRod = 'A', auxiliaryRod = 'B', destinationRod = 'C';

    if (n % 2 == 0) {
        char temp = auxiliaryRod;
        auxiliaryRod = destinationRod;
        destinationRod = temp;
    }

    for (int move = 1; move <= totalMoves; move++) {
        if (move % 3 == 1) {
            if (!isEmpty(source) && (isEmpty(auxiliary) || peek(source) < peek(auxiliary))) {
                push(auxiliary, pop(source));
                printf("Move disk %d from rod %c to rod %c\n", peek(auxiliary), sourceRod, auxiliaryRod);
            } else {
                push(source, pop(auxiliary));
                printf("Move disk %d from rod %c to rod %c\n", peek(source), auxiliaryRod, sourceRod);
            }
        } else if (move % 3 == 2) {
            if (!isEmpty(source) && (isEmpty(destination) || peek(source) < peek(destination))) {
                push(destination, pop(source));
                printf("Move disk %d from rod %c to rod %c\n", peek(destination), sourceRod, destinationRod);
            } else {
                push(source, pop(destination));
                printf("Move disk %d from rod %c to rod %c\n", peek(source), destinationRod, sourceRod);
            }
        } else if (move % 3 == 0) {
            if (!isEmpty(auxiliary) && (isEmpty(destination) || peek(auxiliary) < peek(destination))) {
                push(destination, pop(auxiliary));
                printf("Move disk %d from rod %c to rod %c\n", peek(destination), auxiliaryRod, destinationRod);
            } else {
                push(auxiliary, pop(destination));
                printf("Move disk %d from rod %c to rod %c\n", peek(auxiliary), destinationRod, auxiliaryRod);
            }
        }
    }
}

int main() {
    Stack source, auxiliary, destination;
    initialize(&source);
    initialize(&auxiliary);
    initialize(&destination);

    int n;
    printf("Enter the number of disks: ");
    scanf("%d", &n);

    for (int i = n; i >= 1; i--) {
        push(&source, i);
    }

    printf("The sequence of moves involved in the Tower of Hanoi are:\n");
    towerOfHanoi(n, &source, &auxiliary, &destination);

    return 0;
}
