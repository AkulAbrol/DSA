#include<stdio.h>
#include<stdlib.h>
#include "mystack.h"
typedef struct mystack* mystackp;
mystackp create();

mystackp create()
{
    mystackp s=(mystackp)malloc(sizeof(struct mystack));
    s->top=-1;
    return s;
}

void push(mystackp s, int d)
{
    //s->top++;
    s->a[++s->top]=d;
}
void pop(mystackp s)
{
    s->top--;
}
