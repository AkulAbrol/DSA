#include<stdio.h>
struct mystack{
int a[100];
int top;
};

typedef struct mystack* mystackp;
mystackp create();
void push(mystackp, int);
//void pop(struct mystack);
//int getTop(struct mystack);
//bool isEmpty(struct mystack);