#include <stdio.h>
#include "mystack.h"

int main()
{
    mystackp st=create();
    printf("%d\n",st->top);
    
    push(st,10);
    printf("%d\n",st->top);
    push(st,20);
    printf("%d\n",st->top);
    push(st,30);

      printf("%d\n",st->top);

    
    printf("%d\n",st->top);
    push(st,40);
    printf("%d\n",st->top);
    return 0;
}