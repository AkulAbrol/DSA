#include<stdio.h>
#include<stdlib.h>
#include "mystack.h"
#define MAX 10
struct stack *s,*a,*d
    if (p==1){
        push(d,pop (s));
        return;
    }

TOH(n,s,a,d);
TOH(n-1,s,d,a);
TOH(1,s,a,d);
TOH(n-1,a,s,d);
}
int main(){
    
     s=create(s);
      a=create(a);
        d=create(d);
    
       
    push (s,10);
    push (s,20);
    push (s,30);
    
}