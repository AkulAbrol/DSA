typedef struct node{
    int data;
    struct node *prev,*next;
}node;

struct node *head;
void insertionatbeginning();
